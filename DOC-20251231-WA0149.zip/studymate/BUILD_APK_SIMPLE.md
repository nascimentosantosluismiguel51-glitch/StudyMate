# StudyMate - Guia Simplificado para Gerar APK/AAB

## ✅ O que já foi feito:

- ✅ Certificado de assinatura gerado: `keystores/studymate-release-key.keystore`
- ✅ Senha: `studymate123`
- ✅ app.json configurado
- ✅ Ícones e assets prontos
- ✅ Dependências Expo instaladas

---

## 🚀 Próximas Etapas (Escolha uma):

### OPÇÃO A: Usar Expo Cloud Build (RECOMENDADO - Mais Fácil)

1. **Criar conta Expo** (gratuita)
   ```bash
   eas login
   # Ou acesse: https://expo.dev
   ```

2. **Gerar build APK**
   ```bash
   cd /home/ubuntu/studymate
   eas build --platform android --type apk
   ```

3. **Gerar build AAB** (para Play Store)
   ```bash
   eas build --platform android --type app-bundle
   ```

4. **Download automático**
   - O build será feito na nuvem
   - Link de download será exibido no terminal
   - Arquivo pronto para Play Store

**Tempo**: 10-15 minutos
**Custo**: Gratuito (com limites)

---

### OPÇÃO B: Build Local com React Native CLI

1. **Instalar Android SDK** (se não tiver)
   ```bash
   # macOS
   brew install android-sdk
   
   # Linux
   sudo apt-get install android-sdk android-sdk-build-tools gradle
   
   # Windows
   # Baixe de: https://developer.android.com/studio
   ```

2. **Configurar variáveis de ambiente**
   ```bash
   export ANDROID_HOME=$HOME/Android/Sdk
   export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools
   ```

3. **Gerar build APK**
   ```bash
   cd /home/ubuntu/studymate
   npx react-native build-android --mode=release
   ```

4. **Assinar com certificado**
   ```bash
   jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 \
     -keystore keystores/studymate-release-key.keystore \
     app-release-unsigned.apk studymate
   ```

**Tempo**: 20-30 minutos
**Custo**: Gratuito
**Requisito**: Android SDK instalado

---

### OPÇÃO C: Usar Expo Go (Teste Rápido)

```bash
# Instalar Expo Go no seu celular
# https://play.google.com/store/apps/details?id=host.exp.exponent

# Iniciar servidor Expo
npx expo start

# Escanear QR code com Expo Go
```

**Tempo**: 2 minutos
**Custo**: Gratuito
**Uso**: Testar antes de publicar

---

## 📱 Arquivos Gerados

Após o build, você terá:

- **APK**: `app-release.apk` (arquivo único, ~50-100MB)
  - Usado para testes
  - Pode instalar diretamente no celular

- **AAB**: `app-release.aab` (arquivo bundle, ~30-50MB)
  - Usado para Play Store
  - Google Play gera APKs otimizados automaticamente
  - **RECOMENDADO para publicação**

---

## 📤 Publicar na Play Store

Após gerar o AAB:

1. **Acessar Google Play Console**
   ```
   https://play.google.com/console
   ```

2. **Criar novo app**
   - Nome: StudyMate
   - Categoria: Educação
   - Tipo: Aplicativo

3. **Upload do AAB**
   - Vá para: Release → Production
   - Clique: Create new release
   - Upload: app-release.aab

4. **Preencher informações**
   - Descrição (já preparada)
   - Screenshots
   - Ícone
   - Política de privacidade

5. **Revisar e publicar**
   - Clique: Review release
   - Clique: Start rollout to Production

6. **Aguardar aprovação**
   - Tempo: 24-48 horas (primeira vez)
   - Após aprovação: disponível na Play Store

---

## 🔐 Informações do Certificado

```
Arquivo: keystores/studymate-release-key.keystore
Alias: studymate
Senha: studymate123
Validade: 10.000 dias (27 anos)
Algoritmo: RSA 2048-bit
```

**⚠️ IMPORTANTE**: Guarde este arquivo em local seguro! Você precisará dele para:
- Atualizar o app
- Gerar novas versões
- Manter a mesma assinatura

---

## ✅ Checklist Final

- [ ] Certificado gerado: `keystores/studymate-release-key.keystore`
- [ ] app.json configurado
- [ ] Ícones criados em `assets/`
- [ ] Dependências instaladas
- [ ] Build APK/AAB gerado
- [ ] Conta Google Play Developer criada ($25)
- [ ] AAB enviado para Play Store
- [ ] Informações da loja preenchidas
- [ ] App publicado e disponível

---

## 🆘 Troubleshooting

### Erro: "Expo CLI not found"
```bash
npm install -g eas-cli expo-cli
```

### Erro: "Android SDK not found"
```bash
# Instalar Android SDK
# https://developer.android.com/studio
```

### Erro: "Certificado inválido"
```bash
# Regenerar certificado
./generate-keystore.sh
```

### Build muito lento
- Usar Expo Cloud Build (mais rápido)
- Aumentar RAM disponível
- Fechar outros programas

---

## 📞 Recursos Úteis

- **Expo Docs**: https://docs.expo.dev/build/setup/
- **React Native Docs**: https://reactnative.dev/docs/signed-apk-android
- **Google Play Console**: https://play.google.com/console
- **Android Studio**: https://developer.android.com/studio

---

## 🎯 Resumo Rápido

**Para publicar na Play Store em 30 minutos:**

1. Criar conta Expo (gratuita): https://expo.dev
2. Executar: `eas build --platform android --type app-bundle`
3. Criar conta Google Play Developer: $25
4. Fazer upload do AAB no Google Play Console
5. Preencher informações e publicar

**Pronto! Seu app estará na Play Store em 24-48 horas!** 🚀

---

**Dúvidas? Consulte os guias:**
- `PLAY_STORE_GUIDE.md` - Guia completo
- `MARKETING_STRATEGY.md` - Estratégia de marketing
