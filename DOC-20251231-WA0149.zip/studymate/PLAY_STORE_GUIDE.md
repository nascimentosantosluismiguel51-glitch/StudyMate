# StudyMate - Guia Completo de Publicação na Play Store

## 📋 Pré-requisitos

1. **Conta Google Play Developer** ($25 uma única vez)
   - Acesse: https://play.google.com/console
   - Crie uma conta de desenvolvedor

2. **Java Development Kit (JDK)** instalado
3. **Android SDK** instalado
4. **Expo CLI** instalado (`npm install -g expo-cli`)

---

## 🔐 Passo 1: Gerar Certificado de Assinatura Digital

### Opção A: Usar Expo (Recomendado - Mais Fácil)

```bash
cd /home/ubuntu/studymate
eas build --platform android --type apk
```

Siga as instruções do Expo. Ele gerará automaticamente um certificado e fará o build.

### Opção B: Gerar Manualmente com Keytool

```bash
# Gerar keystore
keytool -genkey -v -keystore studymate-release-key.keystore -keyalg RSA -keysize 2048 -validity 10000 -alias studymate

# Quando solicitado, forneça:
# - Senha do keystore: [escolha uma senha forte]
# - Nome: [seu nome]
# - Organização: StudyMate
# - País: BR (ou seu país)
```

Guarde o arquivo `studymate-release-key.keystore` em local seguro!

---

## 📦 Passo 2: Gerar Build APK/AAB

### Método 1: Usando Expo (Recomendado)

```bash
# Build APK
eas build --platform android --type apk

# Build AAB (recomendado para Play Store)
eas build --platform android --type app-bundle
```

### Método 2: Build Local com React Native

```bash
# Instalar dependências
cd /home/ubuntu/studymate
npm install

# Gerar build de release
npx react-native build-android --mode=release
```

---

## 📱 Passo 3: Preparar Informações para Play Store

### App Name
- **Nome**: StudyMate
- **Descrição Curta**: Smart Learning Assistant with AI

### Descrição Completa (Português)
```
StudyMate - Seu Assistente Inteligente de Estudos

Aprenda melhor, memorize mais e arrase nos exames com ferramentas de estudo alimentadas por IA!

✨ Funcionalidades:
📝 Resumos Inteligentes - Gere resumos automáticos de qualquer texto ou documento
📚 Flashcards Inteligentes - Crie flashcards com repetição espaçada para melhor memorização
❓ Questionários Personalizados - Gere testes automáticos para testar seu conhecimento
📊 Rastreamento de Progresso - Monitore seu desempenho e progresso nos estudos
💡 Dicas Socráticas - Receba dicas que guiam seu pensamento crítico
🌍 Multilíngue - Disponível em Português, Espanhol, Inglês e Francês

StudyMate usa tecnologia de IA avançada para criar conteúdo de estudo personalizado que se adapta ao seu estilo de aprendizagem. Perfeito para estudantes de todas as idades!

Disponível em múltiplos idiomas:
- Português Brasileiro
- Espanhol
- Inglês
- Francês

Comece a estudar de forma inteligente hoje mesmo!
```

### Screenshots Necessárias
- Mínimo 2, máximo 8 screenshots
- Tamanho: 1080 x 1920 pixels
- Mostrar: Home, Documents, Quiz, Results

### Ícone do App
- Já criado em: `/home/ubuntu/studymate/assets/icon.png`
- Tamanho: 512 x 512 pixels

### Categoria
- **Categoria**: Educação
- **Classificação Etária**: 3+ anos

---

## 🚀 Passo 4: Publicar na Play Store

### 1. Acessar Google Play Console
- Vá para https://play.google.com/console
- Clique em "Create app"

### 2. Preencher Informações Básicas
- Nome do app: StudyMate
- Idioma padrão: Português (Brasil)
- Tipo: Aplicativo
- Categoria: Educação

### 3. Completar Formulário de Consentimento
- Preencha questões sobre privacidade, conteúdo, etc.

### 4. Adicionar Detalhes da Loja
- **Título**: StudyMate - Smart Learning Assistant
- **Descrição curta**: Learn better with AI-powered study tools
- **Descrição completa**: [Use o texto acima]
- **Ícone**: Upload do arquivo `icon.png`
- **Screenshots**: Upload de 2-8 screenshots

### 5. Configurar Preço e Distribuição
- **Preço**: Gratuito (ou pago se preferir)
- **Países**: Selecione todos os países desejados
- **Classificação de conteúdo**: Preencha o formulário

### 6. Upload do APK/AAB
- Vá para "Release" → "Production"
- Clique em "Create new release"
- Upload do arquivo APK ou AAB gerado

### 7. Revisar e Publicar
- Revise todas as informações
- Clique em "Review release"
- Clique em "Start rollout to Production"

---

## ⏱️ Tempo de Aprovação

- **Primeira publicação**: 24-48 horas
- **Atualizações**: 2-4 horas geralmente

---

## 🔄 Atualizações Futuras

Para atualizar o app:

```bash
# Incrementar versão em app.json
# Exemplo: "version": "1.0.1"

# Gerar novo build
eas build --platform android --type app-bundle

# Fazer upload na Play Store Console
```

---

## 📊 Monitorar Performance

Após publicação, você pode monitorar:
- Downloads e instalações
- Avaliações e comentários
- Crashes e erros
- Retenção de usuários
- Receita (se monetizado)

Tudo isso está disponível no Google Play Console.

---

## 💰 Estratégia de Monetização

### Opções:
1. **Gratuito com Ads** - Adicionar Google AdMob
2. **Freemium** - Versão gratuita + premium
3. **Pago** - Cobrar valor fixo
4. **Assinatura** - Modelo de subscription

Recomendamos começar com **Gratuito com Ads** para ganhar tração.

---

## 🎯 Próximos Passos

1. ✅ Gerar certificado de assinatura
2. ✅ Criar build APK/AAB
3. ✅ Preparar screenshots e descrição
4. ✅ Criar conta Google Play Developer
5. ✅ Publicar na Play Store
6. ✅ Implementar estratégia de marketing
7. ✅ Monitorar performance e feedback

---

## 📞 Suporte

Para dúvidas sobre publicação:
- Google Play Console Help: https://support.google.com/googleplay/android-developer
- Expo Documentation: https://docs.expo.dev/build/setup/

---

**Boa sorte! 🚀**
