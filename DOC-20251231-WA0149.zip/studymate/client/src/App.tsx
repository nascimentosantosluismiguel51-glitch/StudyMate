import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Documents from "./pages/Documents";
import Flashcards from "./pages/Flashcards";
import Quizzes from "./pages/Quizzes";
import Progress from "./pages/Progress";
import DocumentSummary from "./pages/DocumentSummary";
import DocumentFlashcards from "./pages/DocumentFlashcards";
import DocumentQuiz from "./pages/DocumentQuiz";
import QuizTake from "./pages/QuizTake";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/documents"} component={Documents} />
      <Route path={"/documents/:documentId/summary"} component={({ params }) => <DocumentSummary documentId={params.documentId} />} />
      <Route path={"/documents/:documentId/flashcards"} component={({ params }) => <DocumentFlashcards documentId={params.documentId} />} />
      <Route path={"/documents/:documentId/quiz"} component={({ params }) => <DocumentQuiz documentId={params.documentId} />} />
      <Route path={"/flashcards"} component={Flashcards} />
      <Route path={"/quizzes"} component={Quizzes} />
      <Route path={"/quizzes/:quizId/take"} component={({ params }) => <QuizTake quizId={params.quizId} />} />
      <Route path={"/progress"} component={Progress} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
