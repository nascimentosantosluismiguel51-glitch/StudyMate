import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";
import { Loader2, ArrowLeft, BookOpen } from "lucide-react";
import { useLocation } from "wouter";
import MobileLayout from "@/components/MobileLayout";
import { getLoginUrl } from "@/const";
import { useState } from "react";
import { toast } from "sonner";

interface DocumentFlashcardsProps {
  documentId: string;
}

export default function DocumentFlashcards({ documentId }: DocumentFlashcardsProps) {
  const { user, loading: authLoading } = useAuth();
  const { language, t } = useLanguage();
  const [, navigate] = useLocation();
  const [count, setCount] = useState(10);

  const docId = parseInt(documentId);

  const { data: document } = trpc.document.getById.useQuery(
    { id: docId },
    { enabled: !!user && !!docId }
  );

  const generateMutation = trpc.flashcard.generateFromDocument.useMutation({
    onSuccess: (data) => {
      toast.success(`Generated ${data.count} flashcards!`);
      setTimeout(() => navigate("/flashcards"), 1500);
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const handleGenerate = async () => {
    if (!document) return;
    await generateMutation.mutateAsync({
      documentId: docId,
      content: document.content,
      language: language as any,
      count,
    });
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    window.location.href = getLoginUrl();
    return null;
  }

  return (
    <MobileLayout>
      <div className="space-y-6 pb-20 md:pb-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate("/documents")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">{t.documents.createFlashcards}</h1>
            <p className="text-muted-foreground mt-1">{document?.title}</p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-primary" />
              {t.flashcards.createNew}
            </CardTitle>
            <CardDescription>
              AI will automatically generate flashcards from your document
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="count">Number of Flashcards</Label>
              <Input
                id="count"
                type="number"
                min="1"
                max="20"
                value={count}
                onChange={(e) => setCount(parseInt(e.target.value) || 10)}
              />
              <p className="text-sm text-muted-foreground">
                Generate between 1 and 20 flashcards
              </p>
            </div>

            <div className="bg-secondary/50 p-4 rounded-lg">
              <p className="text-sm">
                <strong>How it works:</strong> Our AI will analyze your document and create {count}{" "}
                flashcards with questions on the front and answers on the back. You can review and
                edit them later.
              </p>
            </div>

            <Button
              onClick={handleGenerate}
              disabled={generateMutation.isPending}
              className="w-full"
              size="lg"
            >
              {generateMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {generateMutation.isPending ? "Generating..." : "Generate Flashcards"}
            </Button>
          </CardContent>
        </Card>
      </div>
    </MobileLayout>
  );
}
