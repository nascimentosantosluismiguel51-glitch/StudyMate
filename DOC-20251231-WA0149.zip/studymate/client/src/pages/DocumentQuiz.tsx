import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";
import { Loader2, ArrowLeft, HelpCircle } from "lucide-react";
import { useLocation } from "wouter";
import MobileLayout from "@/components/MobileLayout";
import { getLoginUrl } from "@/const";
import { useState } from "react";
import { toast } from "sonner";

interface DocumentQuizProps {
  documentId: string;
}

export default function DocumentQuiz({ documentId }: DocumentQuizProps) {
  const { user, loading: authLoading } = useAuth();
  const { language, t } = useLanguage();
  const [, navigate] = useLocation();
  const [title, setTitle] = useState("Quiz");
  const [questionCount, setQuestionCount] = useState(10);

  const docId = parseInt(documentId);

  const { data: document } = trpc.document.getById.useQuery(
    { id: docId },
    { enabled: !!user && !!docId }
  );

  const generateMutation = trpc.quiz.generateFromDocument.useMutation({
    onSuccess: (data) => {
      toast.success(`Generated ${data.questionCount} questions!`);
      setTimeout(() => navigate("/quizzes"), 1500);
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const handleGenerate = async () => {
    if (!document || !title.trim()) {
      toast.error("Please enter a quiz title");
      return;
    }
    await generateMutation.mutateAsync({
      documentId: docId,
      content: document.content,
      language: language as any,
      questionCount,
      title,
    });
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    window.location.href = getLoginUrl();
    return null;
  }

  return (
    <MobileLayout>
      <div className="space-y-6 pb-20 md:pb-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate("/documents")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">{t.documents.createQuiz}</h1>
            <p className="text-muted-foreground mt-1">{document?.title}</p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <HelpCircle className="h-5 w-5 text-primary" />
              {t.quizzes.createNew}
            </CardTitle>
            <CardDescription>
              AI will automatically generate quiz questions from your document
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title">Quiz Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter quiz title"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="questions">Number of Questions</Label>
              <Input
                id="questions"
                type="number"
                min="1"
                max="20"
                value={questionCount}
                onChange={(e) => setQuestionCount(parseInt(e.target.value) || 10)}
              />
              <p className="text-sm text-muted-foreground">
                Generate between 1 and 20 multiple-choice questions
              </p>
            </div>

            <div className="bg-secondary/50 p-4 rounded-lg">
              <p className="text-sm">
                <strong>How it works:</strong> Our AI will create {questionCount} multiple-choice
                questions with 4 options each. Each question includes an explanation for the
                correct answer.
              </p>
            </div>

            <Button
              onClick={handleGenerate}
              disabled={generateMutation.isPending}
              className="w-full"
              size="lg"
            >
              {generateMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {generateMutation.isPending ? "Generating..." : "Generate Quiz"}
            </Button>
          </CardContent>
        </Card>
      </div>
    </MobileLayout>
  );
}
