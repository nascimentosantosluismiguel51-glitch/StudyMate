import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";
import { Loader2, ArrowLeft, Sparkles } from "lucide-react";
import { useLocation } from "wouter";
import MobileLayout from "@/components/MobileLayout";
import { getLoginUrl } from "@/const";
import { useEffect, useState } from "react";

interface DocumentSummaryProps {
  documentId: string;
}

export default function DocumentSummary({ documentId }: DocumentSummaryProps) {
  const { user, loading: authLoading } = useAuth();
  const { t } = useLanguage();
  const [, navigate] = useLocation();
  const [isGenerating, setIsGenerating] = useState(false);

  const docId = parseInt(documentId);

  const { data: document } = trpc.document.getById.useQuery(
    { id: docId },
    { enabled: !!user && !!docId }
  );

  const { data: summary } = trpc.summary.getByDocumentId.useQuery(
    { documentId: docId },
    { enabled: !!user && !!docId }
  );

  const generateSummaryMutation = trpc.summary.generate.useMutation({
    onSuccess: () => {
      setIsGenerating(false);
    },
  });

  const handleGenerateSummary = async () => {
    if (!document) return;
    setIsGenerating(true);
    await generateSummaryMutation.mutateAsync({
      documentId: docId,
      content: document.content,
      language: document.language as any,
    });
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    window.location.href = getLoginUrl();
    return null;
  }

  return (
    <MobileLayout>
      <div className="space-y-6 pb-20 md:pb-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate("/documents")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold">{t.documents.viewSummary}</h1>
            <p className="text-muted-foreground mt-1">{document?.title}</p>
          </div>
        </div>

        {summary ? (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" />
                {t.documents.viewSummary}
              </CardTitle>
              <CardDescription>
                Generated on {new Date(summary.createdAt).toLocaleDateString()}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-base leading-relaxed whitespace-pre-wrap">{summary.content}</p>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="pt-6">
              <p className="text-muted-foreground mb-4">
                No summary generated yet. Click the button below to generate one using AI.
              </p>
              <Button
                onClick={handleGenerateSummary}
                disabled={isGenerating || generateSummaryMutation.isPending}
                className="w-full"
              >
                {(isGenerating || generateSummaryMutation.isPending) && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                {t.documents.viewSummary}
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </MobileLayout>
  );
}
