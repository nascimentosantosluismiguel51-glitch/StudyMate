import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";
import { Plus, FileText, Loader2, Trash2, Sparkles } from "lucide-react";
import { toast } from "sonner";
import MobileLayout from "@/components/MobileLayout";
import { getLoginUrl } from "@/const";

export default function Documents() {
  const { user, loading: authLoading } = useAuth();
  const { language, t } = useLanguage();
  const [, navigate] = useLocation();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  const { data: documents, isLoading, refetch } = trpc.document.list.useQuery(undefined, {
    enabled: !!user,
  });

  const createMutation = trpc.document.create.useMutation({
    onSuccess: () => {
      toast.success(t.common.success);
      setIsDialogOpen(false);
      setTitle("");
      setContent("");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const deleteMutation = trpc.document.delete.useMutation({
    onSuccess: () => {
      toast.success(t.common.success);
      refetch();
    },
  });

  const handleCreate = () => {
    if (!title.trim() || !content.trim()) {
      toast.error("Please fill in all fields");
      return;
    }
    createMutation.mutate({
      title,
      content,
      language,
    });
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    window.location.href = getLoginUrl();
    return null;
  }

  return (
    <MobileLayout>
      <div className="space-y-6 pb-20 md:pb-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">{t.documents.title}</h1>
            <p className="text-muted-foreground mt-1">
              {documents?.length || 0} {t.documents.title.toLowerCase()}
            </p>
          </div>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                {t.documents.uploadNew}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>{t.documents.uploadNew}</DialogTitle>
                <DialogDescription>
                  Add a new document to start studying
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Enter document title"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="content">Content</Label>
                  <Textarea
                    id="content"
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder="Paste your text here..."
                    className="min-h-[200px]"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  {t.common.cancel}
                </Button>
                <Button onClick={handleCreate} disabled={createMutation.isPending}>
                  {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {t.common.save}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : documents && documents.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {documents.map((doc) => (
              <Card key={doc.id} className="flex flex-col">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <FileText className="h-8 w-8 text-primary" />
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-destructive"
                      onClick={() => deleteMutation.mutate({ id: doc.id })}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <CardTitle className="line-clamp-2">{doc.title}</CardTitle>
                  <CardDescription className="line-clamp-3">
                    {doc.content.substring(0, 150)}...
                  </CardDescription>
                </CardHeader>
                <CardFooter className="mt-auto flex-col gap-2">
                  <Button variant="outline" className="w-full" size="sm" onClick={() => navigate(`/documents/${doc.id}/summary`)}>
                    <Sparkles className="mr-2 h-4 w-4" />
                    {t.documents.viewSummary}
                  </Button>
                  <div className="flex gap-2 w-full">
                    <Button variant="outline" className="flex-1" size="sm" onClick={() => navigate(`/documents/${doc.id}/flashcards`)}>
                      {t.documents.createFlashcards}
                    </Button>
                    <Button variant="outline" className="flex-1" size="sm" onClick={() => navigate(`/documents/${doc.id}/quiz`)}>
                      {t.documents.createQuiz}
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <FileText className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-lg font-semibold mb-2">{t.documents.noDocuments}</p>
              <p className="text-muted-foreground mb-4">{t.documents.uploadPrompt}</p>
              <Button onClick={() => setIsDialogOpen(true)}>
                <Plus className="mr-2 h-4 w-4" />
                {t.documents.uploadNew}
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </MobileLayout>
  );
}
