import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";
import { Loader2, BookOpen, Plus } from "lucide-react";
import MobileLayout from "@/components/MobileLayout";
import { getLoginUrl } from "@/const";
import { useState } from "react";

export default function Flashcards() {
  const { user, loading: authLoading } = useAuth();
  const { t } = useLanguage();
  const [flipped, setFlipped] = useState<Record<number, boolean>>({});

  const { data: flashcards, isLoading } = trpc.flashcard.list.useQuery(undefined, {
    enabled: !!user,
  });

  const toggleFlip = (id: number) => {
    setFlipped((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    window.location.href = getLoginUrl();
    return null;
  }

  return (
    <MobileLayout>
      <div className="space-y-6 pb-20 md:pb-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">{t.flashcards.title}</h1>
            <p className="text-muted-foreground mt-1">
              {flashcards?.length || 0} {t.flashcards.title.toLowerCase()}
            </p>
          </div>

          <Button>
            <Plus className="mr-2 h-4 w-4" />
            {t.flashcards.createNew}
          </Button>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : flashcards && flashcards.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {flashcards.map((card) => (
              <Card
                key={card.id}
                className="cursor-pointer hover:shadow-lg transition-shadow min-h-[200px]"
                onClick={() => toggleFlip(card.id)}
              >
                <CardContent className="flex items-center justify-center p-6 min-h-[200px]">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground mb-2">
                      {flipped[card.id] ? t.flashcards.back : t.flashcards.front}
                    </p>
                    <p className="text-lg font-medium">
                      {flipped[card.id] ? card.back : card.front}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <BookOpen className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-lg font-semibold mb-2">{t.flashcards.noFlashcards}</p>
              <p className="text-muted-foreground mb-4">Create flashcards from your documents</p>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                {t.flashcards.createNew}
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </MobileLayout>
  );
}
