import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useLanguage } from "@/contexts/LanguageContext";
import { getLoginUrl } from "@/const";
import { BookOpen, Brain, FileText, TrendingUp } from "lucide-react";
import { Link } from "wouter";
import type { Language } from "@shared/i18n";

export default function Home() {
  const { user, loading } = useAuth();
  const { language, setLanguage, t } = useLanguage();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">{t.common.loading}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/20">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="h-6 w-6 text-primary" />
            <span className="font-bold text-xl">StudyMate</span>
          </div>
          
          <div className="flex items-center gap-4">
            <Select value={language} onValueChange={(val) => setLanguage(val as Language)}>
              <SelectTrigger className="w-[120px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="pt">Português</SelectItem>
                <SelectItem value="es">Español</SelectItem>
                <SelectItem value="fr">Français</SelectItem>
              </SelectContent>
            </Select>

            {user ? (
              <Link href="/documents">
                <Button>{t.nav.documents}</Button>
              </Link>
            ) : (
              <Button asChild>
                <a href={getLoginUrl()}>{t.auth.login}</a>
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container py-12 md:py-24">
        <div className="flex flex-col items-center text-center space-y-6">
          <div className="space-y-4 max-w-3xl">
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              {t.home.title}
            </h1>
            <p className="text-xl text-muted-foreground">
              {t.home.subtitle}
            </p>
          </div>

          {user ? (
            <Link href="/documents">
              <Button size="lg" className="text-lg px-8">
                {t.home.getStarted}
              </Button>
            </Link>
          ) : (
            <Button size="lg" className="text-lg px-8" asChild>
              <a href={getLoginUrl()}>{t.home.getStarted}</a>
            </Button>
          )}
        </div>
      </section>

      {/* Features Grid */}
      <section className="container pb-12 md:pb-24">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Card className="border-2 hover:border-primary/50 transition-colors">
            <CardHeader>
              <FileText className="h-10 w-10 text-primary mb-2" />
              <CardTitle>{t.home.features.summarize.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                {t.home.features.summarize.description}
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-primary/50 transition-colors">
            <CardHeader>
              <BookOpen className="h-10 w-10 text-primary mb-2" />
              <CardTitle>{t.home.features.flashcards.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                {t.home.features.flashcards.description}
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-primary/50 transition-colors">
            <CardHeader>
              <Brain className="h-10 w-10 text-primary mb-2" />
              <CardTitle>{t.home.features.quizzes.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                {t.home.features.quizzes.description}
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-primary/50 transition-colors">
            <CardHeader>
              <TrendingUp className="h-10 w-10 text-primary mb-2" />
              <CardTitle>{t.home.features.progress.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                {t.home.features.progress.description}
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-6 md:py-8 bg-background">
        <div className="container text-center text-sm text-muted-foreground">
          <p>© 2025 StudyMate. {t.home.subtitle}</p>
        </div>
      </footer>
    </div>
  );
}
