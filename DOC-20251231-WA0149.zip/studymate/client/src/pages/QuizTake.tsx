import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";
import { Loader2, ArrowLeft, CheckCircle2, XCircle } from "lucide-react";
import { useLocation } from "wouter";
import MobileLayout from "@/components/MobileLayout";
import { getLoginUrl } from "@/const";
import { useState } from "react";
import { toast } from "sonner";

interface QuizTakeProps {
  quizId: string;
}

export default function QuizTake({ quizId }: QuizTakeProps) {
  const { user, loading: authLoading } = useAuth();
  const { t } = useLanguage();
  const [, navigate] = useLocation();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);
  const [socraticHint, setSocraticHint] = useState<string | null>(null);
  const [loadingHint, setLoadingHint] = useState(false);

  const quizIdNum = parseInt(quizId);

  const { data: quiz, isLoading } = trpc.quiz.getById.useQuery(
    { id: quizIdNum },
    { enabled: !!user && !!quizId }
  );

  const socraticTipsMutation = trpc.socraticTips.generate.useMutation({
    onSuccess: (data) => {
      setSocraticHint(data.hint);
      setLoadingHint(false);
    },
    onError: () => {
      setLoadingHint(false);
    },
  });

  const submitAttemptMutation = trpc.quiz.submitAttempt.useMutation({
    onSuccess: (data) => {
      setScore(data.score);
      setShowResults(true);
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    window.location.href = getLoginUrl();
    return null;
  }

  if (isLoading) {
    return (
      <MobileLayout>
        <div className="flex justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MobileLayout>
    );
  }

  if (!quiz || !quiz.questions || quiz.questions.length === 0) {
    return (
      <MobileLayout>
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="icon" onClick={() => navigate("/quizzes")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-3xl font-bold">Quiz not found</h1>
        </div>
      </MobileLayout>
    );
  }

  const currentQuestion = quiz.questions[currentQuestionIndex];
  const isLastQuestion = currentQuestionIndex === quiz.questions.length - 1;
  const allAnswered = Object.keys(selectedAnswers).length === quiz.questions.length;

  const handleSelectAnswer = (optionIndex: number) => {
    setSelectedAnswers({
      ...selectedAnswers,
      [currentQuestionIndex]: optionIndex,
    });
  };

  const handleNext = () => {
    if (currentQuestionIndex < quiz.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSocraticHint(null);
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
      setSocraticHint(null);
    }
  };

  const handleGetHint = () => {
    if (!currentQuestion) return;
    setLoadingHint(true);
    const options = Array.isArray(currentQuestion.options)
      ? currentQuestion.options
      : JSON.parse(currentQuestion.options as string);
    socraticTipsMutation.mutate({
      question: currentQuestion.question,
      options,
      language: "en",
    });
  };

  const handleSubmit = async () => {
    if (!allAnswered) {
      toast.error("Please answer all questions before submitting");
      return;
    }

    const answersAsStrings: Record<string, string> = {};
    Object.entries(selectedAnswers).forEach(([key, value]) => {
      answersAsStrings[key] = String(value);
    });

    await submitAttemptMutation.mutateAsync({
      quizId: quizIdNum,
      answers: answersAsStrings,
    });
  };

  if (showResults) {
    const totalQuestions = quiz.questions.length;
    const percentage = Math.round((score / totalQuestions) * 100);

    return (
      <MobileLayout>
        <div className="space-y-6 pb-20 md:pb-6">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/quizzes")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-3xl font-bold">Quiz Results</h1>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>{quiz.title}</CardTitle>
              <CardDescription>Your performance</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="text-6xl font-bold text-primary mb-2">{percentage}%</div>
                <p className="text-xl text-muted-foreground">
                  You scored {score} out of {totalQuestions} questions
                </p>
              </div>

              <div className="bg-secondary/50 p-4 rounded-lg">
                <p className="text-sm">
                  {percentage >= 80
                    ? "Excellent work! You have a strong understanding of this material."
                    : percentage >= 60
                    ? "Good job! Review the questions you missed to improve further."
                    : "Keep studying! Review the material and try again."}
                </p>
              </div>

              <div className="space-y-3">
                {quiz.questions.map((question: any, index: number) => {
                  const correctAnswerIndex = typeof question.correctAnswer === 'string' ? parseInt(question.correctAnswer) : question.correctAnswer;
                  const isCorrect = selectedAnswers[index] === correctAnswerIndex;
                  return (
                    <div key={index} className="flex items-start gap-3 p-3 bg-secondary/30 rounded-lg">
                      {isCorrect ? (
                        <CheckCircle2 className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-500 mt-0.5 flex-shrink-0" />
                      )}
                      <div className="flex-1">
                        <p className="font-medium text-sm">{question.question}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Your answer: {(Array.isArray(question.options) ? question.options : JSON.parse(question.options as string))[selectedAnswers[index]]}
                        </p>
                        {!isCorrect && (
                          <p className="text-xs text-green-600 mt-1">
                            Correct: {(Array.isArray(question.options) ? question.options : JSON.parse(question.options as string))[correctAnswerIndex]}
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              <Button onClick={() => navigate("/quizzes")} className="w-full">
                Back to Quizzes
              </Button>
            </CardContent>
          </Card>
        </div>
      </MobileLayout>
    );
  }

  return (
    <MobileLayout>
      <div className="space-y-6 pb-20 md:pb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/quizzes")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold">{quiz.title}</h1>
              <p className="text-sm text-muted-foreground">
                Question {currentQuestionIndex + 1} of {quiz.questions.length}
              </p>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-secondary rounded-full h-2">
          <div
            className="bg-primary h-2 rounded-full transition-all"
            style={{
              width: `${((currentQuestionIndex + 1) / quiz.questions.length) * 100}%`,
            }}
          />
        </div>

        {/* Question Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">{currentQuestion.question}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Options */}
            <div className="space-y-3">
              {(Array.isArray(currentQuestion.options) ? currentQuestion.options : JSON.parse(currentQuestion.options as string)).map((option: string, index: number) => (
                <button
                  key={index}
                  onClick={() => handleSelectAnswer(index)}
                  className={`w-full p-4 text-left rounded-lg border-2 transition-colors ${
                    selectedAnswers[currentQuestionIndex] === index
                      ? "border-primary bg-primary/10"
                      : "border-secondary hover:border-primary/50"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                        selectedAnswers[currentQuestionIndex] === index
                          ? "border-primary bg-primary"
                          : "border-muted-foreground"
                      }`}
                    >
                      {selectedAnswers[currentQuestionIndex] === index && (
                        <div className="w-2 h-2 bg-white rounded-full" />
                      )}
                    </div>
                    <span>{option}</span>
                  </div>
                </button>
              ))}
            </div>

            {/* Socratic Hint */}
            {socraticHint && (
              <div className="bg-blue-500/10 border border-blue-500/30 p-3 rounded-lg">
                <p className="text-sm text-blue-300">
                  <strong>💡 Hint:</strong> {socraticHint}
                </p>
              </div>
            )}

            {/* Get Hint Button */}
            <Button
              variant="outline"
              onClick={handleGetHint}
              disabled={loadingHint || socraticHint !== null}
              className="w-full"
            >
              {loadingHint && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {socraticHint ? "Hint Provided" : "Get Hint"}
            </Button>
          </CardContent>
        </Card>

        {/* Navigation Buttons */}
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentQuestionIndex === 0}
            className="flex-1"
          >
            Previous
          </Button>

          {isLastQuestion ? (
            <Button
              onClick={handleSubmit}
              disabled={!allAnswered || submitAttemptMutation.isPending}
              className="flex-1"
            >
              {submitAttemptMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Submit Quiz
            </Button>
          ) : (
            <Button onClick={handleNext} className="flex-1">
              Next
            </Button>
          )}
        </div>

        {/* Answer Summary */}
        <Card className="bg-secondary/30">
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground mb-3">
              Answered: {Object.keys(selectedAnswers).length} / {quiz.questions.length}
            </p>
            <div className="flex flex-wrap gap-2">
              {quiz.questions.map((_: any, index: number) => (
                <button
                  key={index}
                  onClick={() => setCurrentQuestionIndex(index)}
                  className={`w-8 h-8 rounded-lg text-xs font-medium transition-colors ${
                    selectedAnswers[index] !== undefined
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary border border-muted-foreground text-muted-foreground"
                  } ${currentQuestionIndex === index ? "ring-2 ring-primary" : ""}`}
                >
                  {index + 1}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </MobileLayout>
  );
}
