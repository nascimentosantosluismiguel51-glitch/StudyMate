import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";
import { Loader2, HelpCircle, Plus, Play } from "lucide-react";
import { useLocation } from "wouter";
import MobileLayout from "@/components/MobileLayout";
import { getLoginUrl } from "@/const";

export default function Quizzes() {
  const { user, loading: authLoading } = useAuth();
  const { t } = useLanguage();
  const [, navigate] = useLocation();

  const { data: quizzes, isLoading } = trpc.quiz.list.useQuery(undefined, {
    enabled: !!user,
  });

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    window.location.href = getLoginUrl();
    return null;
  }

  return (
    <MobileLayout>
      <div className="space-y-6 pb-20 md:pb-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">{t.quizzes.title}</h1>
            <p className="text-muted-foreground mt-1">
              {quizzes?.length || 0} {t.quizzes.title.toLowerCase()}
            </p>
          </div>

          <Button>
            <Plus className="mr-2 h-4 w-4" />
            {t.quizzes.createNew}
          </Button>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : quizzes && quizzes.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {quizzes.map((quiz) => (
              <Card key={quiz.id}>
                <CardHeader>
                  <HelpCircle className="h-8 w-8 text-primary mb-2" />
                  <CardTitle className="line-clamp-2">{quiz.title}</CardTitle>
                  <CardDescription>
                    Created {new Date(quiz.createdAt).toLocaleDateString()}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    className="w-full"
                    onClick={() => navigate(`/quizzes/${quiz.id}/take`)}
                  >
                    <Play className="mr-2 h-4 w-4" />
                    {t.quizzes.start}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <HelpCircle className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-lg font-semibold mb-2">{t.quizzes.noQuizzes}</p>
              <p className="text-muted-foreground mb-4">Create quizzes from your documents</p>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                {t.quizzes.createNew}
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </MobileLayout>
  );
}
