#!/bin/bash

# Script para gerar certificado de assinatura para Play Store
# Uso: ./generate-keystore.sh

echo "================================"
echo "StudyMate - Gerador de Keystore"
echo "================================"
echo ""

# Verificar se keytool está disponível
if ! command -v keytool &> /dev/null; then
    echo "❌ Erro: keytool não encontrado. Instale Java Development Kit (JDK)."
    exit 1
fi

# Diretório de saída
KEYSTORE_DIR="./keystores"
KEYSTORE_FILE="$KEYSTORE_DIR/studymate-release-key.keystore"

# Criar diretório se não existir
mkdir -p "$KEYSTORE_DIR"

# Verificar se keystore já existe
if [ -f "$KEYSTORE_FILE" ]; then
    echo "⚠️  Aviso: Keystore já existe em $KEYSTORE_FILE"
    read -p "Deseja sobrescrever? (s/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Ss]$ ]]; then
        echo "Operação cancelada."
        exit 0
    fi
fi

echo "Gerando certificado de assinatura..."
echo ""
echo "Você será solicitado a fornecer informações. Pressione Enter para prosseguir."
echo ""

# Gerar keystore
keytool -genkey -v \
    -keystore "$KEYSTORE_FILE" \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -alias studymate

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Keystore gerado com sucesso!"
    echo "📁 Localização: $KEYSTORE_FILE"
    echo ""
    echo "⚠️  IMPORTANTE:"
    echo "   - Guarde este arquivo em local seguro"
    echo "   - Não compartilhe a senha com ninguém"
    echo "   - Faça backup do arquivo"
    echo ""
    echo "Para usar este keystore no build:"
    echo "   1. Copie o arquivo para um local seguro"
    echo "   2. Use as credenciais ao fazer build com Expo ou React Native"
    echo ""
else
    echo "❌ Erro ao gerar keystore. Tente novamente."
    exit 1
fi
