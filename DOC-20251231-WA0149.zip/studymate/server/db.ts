import { eq, desc, and, gte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users,
  documents,
  summaries,
  flashcards,
  quizzes,
  quizQuestions,
  quizAttempts,
  notes,
  studySessions,
  type InsertDocument,
  type InsertSummary,
  type InsertFlashcard,
  type InsertQuiz,
  type InsertQuizQuestion,
  type InsertQuizAttempt,
  type InsertNote,
  type InsertStudySession
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Document helpers
export async function createDocument(doc: InsertDocument) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(documents).values(doc);
  return result;
}

export async function getUserDocuments(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(documents).where(eq(documents.userId, userId)).orderBy(desc(documents.createdAt));
}

export async function getDocumentById(documentId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(documents).where(eq(documents.id, documentId)).limit(1);
  return result[0];
}

export async function deleteDocument(documentId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(documents).where(eq(documents.id, documentId));
}

// Summary helpers
export async function createSummary(summary: InsertSummary) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(summaries).values(summary);
  return result;
}

export async function getSummaryByDocumentId(documentId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(summaries).where(eq(summaries.documentId, documentId)).limit(1);
  return result[0];
}

// Flashcard helpers
export async function createFlashcard(flashcard: InsertFlashcard) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(flashcards).values(flashcard);
  return result;
}

export async function getUserFlashcards(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(flashcards).where(eq(flashcards.userId, userId)).orderBy(desc(flashcards.createdAt));
}

export async function getFlashcardsDueForReview(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const now = new Date();
  return db.select().from(flashcards)
    .where(
      and(
        eq(flashcards.userId, userId),
        gte(flashcards.nextReviewDate, now)
      )
    )
    .orderBy(flashcards.nextReviewDate);
}

export async function updateFlashcard(id: number, data: Partial<InsertFlashcard>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(flashcards).set(data).where(eq(flashcards.id, id));
}

export async function deleteFlashcard(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(flashcards).where(eq(flashcards.id, id));
}

// Quiz helpers
export async function createQuiz(quiz: InsertQuiz) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(quizzes).values(quiz);
  return result;
}

export async function getUserQuizzes(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(quizzes).where(eq(quizzes.userId, userId)).orderBy(desc(quizzes.createdAt));
}

export async function getQuizById(quizId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(quizzes).where(eq(quizzes.id, quizId)).limit(1);
  return result[0];
}

export async function createQuizQuestion(question: InsertQuizQuestion) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(quizQuestions).values(question);
}

export async function getQuizQuestions(quizId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(quizQuestions).where(eq(quizQuestions.quizId, quizId)).orderBy(quizQuestions.order);
}

export async function createQuizAttempt(attempt: InsertQuizAttempt) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(quizAttempts).values(attempt);
}

export async function getUserQuizAttempts(userId: number, quizId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(quizAttempts)
    .where(and(eq(quizAttempts.userId, userId), eq(quizAttempts.quizId, quizId)))
    .orderBy(desc(quizAttempts.completedAt));
}

// Notes helpers
export async function createNote(note: InsertNote) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(notes).values(note);
  return result;
}

export async function getDocumentNotes(documentId: number, userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(notes)
    .where(and(eq(notes.documentId, documentId), eq(notes.userId, userId)))
    .orderBy(notes.position);
}

export async function updateNote(id: number, content: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(notes).set({ content }).where(eq(notes.id, id));
}

export async function deleteNote(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(notes).where(eq(notes.id, id));
}

// Study session helpers
export async function createStudySession(session: InsertStudySession) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(studySessions).values(session);
  return result;
}

export async function getUserStudySessions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(studySessions)
    .where(eq(studySessions.userId, userId))
    .orderBy(desc(studySessions.startedAt));
}

export async function updateStudySession(id: number, data: Partial<InsertStudySession>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(studySessions).set(data).where(eq(studySessions.id, id));
}
