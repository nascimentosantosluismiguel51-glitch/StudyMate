import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { storagePut } from "./storage";
import * as db from "./db";
import { nanoid } from "nanoid";

// Document router
export const documentRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    return db.getUserDocuments(ctx.user.id);
  }),

  create: protectedProcedure
    .input(
      z.object({
        title: z.string(),
        content: z.string(),
        language: z.enum(["en", "pt", "es", "fr"]).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await db.createDocument({
        userId: ctx.user.id,
        title: input.title,
        content: input.content,
        language: input.language || "en",
      });
      return { success: true };
    }),

  uploadFile: protectedProcedure
    .input(
      z.object({
        title: z.string(),
        content: z.string(),
        fileData: z.string(), // base64
        mimeType: z.string(),
        language: z.enum(["en", "pt", "es", "fr"]).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const fileBuffer = Buffer.from(input.fileData, "base64");
      const fileKey = `${ctx.user.id}/documents/${nanoid()}-${input.title}`;
      
      const { url } = await storagePut(fileKey, fileBuffer, input.mimeType);

      await db.createDocument({
        userId: ctx.user.id,
        title: input.title,
        content: input.content,
        fileUrl: url,
        fileKey: fileKey,
        mimeType: input.mimeType,
        language: input.language || "en",
      });

      return { success: true, url };
    }),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return db.getDocumentById(input.id);
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await db.deleteDocument(input.id);
      return { success: true };
    }),
});

// Summary router
export const summaryRouter = router({
  generate: protectedProcedure
    .input(
      z.object({
        documentId: z.number(),
        content: z.string(),
        language: z.enum(["en", "pt", "es", "fr"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const languageMap = {
        en: "English",
        pt: "Portuguese",
        es: "Spanish",
        fr: "French",
      };

      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: `You are an expert study assistant. Create a comprehensive summary of the provided text in ${languageMap[input.language]}. Focus on key concepts, main ideas, and important details that would help a student understand and remember the material.`,
          },
          {
            role: "user",
            content: input.content,
          },
        ],
      });

      const summaryContent = response.choices[0]?.message?.content || "";
      const summary = typeof summaryContent === 'string' ? summaryContent : JSON.stringify(summaryContent);

      await db.createSummary({
        documentId: input.documentId,
        userId: ctx.user.id,
        content: summary,
      });

      return { summary };
    }),

  getByDocumentId: protectedProcedure
    .input(z.object({ documentId: z.number() }))
    .query(async ({ input }) => {
      return db.getSummaryByDocumentId(input.documentId);
    }),
});

// Flashcard router
export const flashcardRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    return db.getUserFlashcards(ctx.user.id);
  }),

  dueForReview: protectedProcedure.query(async ({ ctx }) => {
    return db.getFlashcardsDueForReview(ctx.user.id);
  }),

  create: protectedProcedure
    .input(
      z.object({
        front: z.string(),
        back: z.string(),
        documentId: z.number().optional(),
        difficulty: z.enum(["easy", "medium", "hard"]).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await db.createFlashcard({
        userId: ctx.user.id,
        front: input.front,
        back: input.back,
        documentId: input.documentId,
        difficulty: input.difficulty || "medium",
        nextReviewDate: new Date(Date.now() + 24 * 60 * 60 * 1000), // 1 day from now
      });
      return { success: true };
    }),

  generateFromDocument: protectedProcedure
    .input(
      z.object({
        documentId: z.number(),
        content: z.string(),
        language: z.enum(["en", "pt", "es", "fr"]),
        count: z.number().min(1).max(20).default(10),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const languageMap = {
        en: "English",
        pt: "Portuguese",
        es: "Spanish",
        fr: "French",
      };

      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: `You are an expert study assistant. Generate ${input.count} flashcards in ${languageMap[input.language]} from the provided text. Each flashcard should have a clear question/concept on the front and a concise answer on the back. Return ONLY a valid JSON array with this exact structure: [{"front": "question", "back": "answer"}]. Do not include any markdown formatting, code blocks, or additional text.`,
          },
          {
            role: "user",
            content: input.content,
          },
        ],
      });

      const content = response.choices[0]?.message?.content || "[]";
      const contentStr = typeof content === 'string' ? content : JSON.stringify(content);
      const cleanContent = contentStr.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
      const flashcards = JSON.parse(cleanContent) as Array<{ front: string; back: string }>;

      for (const card of flashcards) {
        await db.createFlashcard({
          userId: ctx.user.id,
          documentId: input.documentId,
          front: card.front,
          back: card.back,
          difficulty: "medium",
          nextReviewDate: new Date(Date.now() + 24 * 60 * 60 * 1000),
        });
      }

      return { count: flashcards.length };
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        difficulty: z.enum(["easy", "medium", "hard"]).optional(),
        nextReviewDate: z.date().optional(),
        reviewCount: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const { id, ...data } = input;
      await db.updateFlashcard(id, data);
      return { success: true };
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await db.deleteFlashcard(input.id);
      return { success: true };
    }),
});

// Quiz router
export const quizRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    return db.getUserQuizzes(ctx.user.id);
  }),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const quiz = await db.getQuizById(input.id);
      if (!quiz) return null;

      const questions = await db.getQuizQuestions(input.id);
      return { ...quiz, questions };
    }),

  generateFromDocument: protectedProcedure
    .input(
      z.object({
        documentId: z.number(),
        content: z.string(),
        language: z.enum(["en", "pt", "es", "fr"]),
        questionCount: z.number().min(1).max(20).default(10),
        title: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const languageMap = {
        en: "English",
        pt: "Portuguese",
        es: "Spanish",
        fr: "French",
      };

      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: `You are an expert study assistant. Generate ${input.questionCount} multiple-choice questions in ${languageMap[input.language]} from the provided text. Each question should have 4 options with only one correct answer. Return ONLY a valid JSON array with this exact structure: [{"question": "text", "options": ["A", "B", "C", "D"], "correctAnswer": "A", "explanation": "why"}]. Do not include any markdown formatting, code blocks, or additional text.`,
          },
          {
            role: "user",
            content: input.content,
          },
        ],
      });

      const content = response.choices[0]?.message?.content || "[]";
      const contentStr = typeof content === 'string' ? content : JSON.stringify(content);
      const cleanContent = contentStr.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
      const questions = JSON.parse(cleanContent) as Array<{
        question: string;
        options: string[];
        correctAnswer: string;
        explanation?: string;
      }>;

      const result = await db.createQuiz({
        userId: ctx.user.id,
        documentId: input.documentId,
        title: input.title,
      }) as any;

      const quizId = Number(result[0].insertId);

      for (let i = 0; i < questions.length; i++) {
        const q = questions[i];
        await db.createQuizQuestion({
          quizId,
          question: q.question,
          options: JSON.stringify(q.options),
          correctAnswer: q.correctAnswer,
          explanation: q.explanation || null,
          order: i + 1,
        });
      }

      return { quizId, questionCount: questions.length };
    }),

  submitAttempt: protectedProcedure
    .input(
      z.object({
        quizId: z.number(),
        answers: z.record(z.string(), z.string()), // questionId -> answer
      })
    )
    .mutation(async ({ ctx, input }) => {
      const questions = await db.getQuizQuestions(input.quizId);
      let score = 0;

      for (const q of questions) {
        const userAnswer = input.answers[q.id.toString()];
        if (userAnswer === q.correctAnswer) {
          score++;
        }
      }

      await db.createQuizAttempt({
        userId: ctx.user.id,
        quizId: input.quizId,
        score,
        totalQuestions: questions.length,
        answers: JSON.stringify(input.answers),
      });

      return { score, totalQuestions: questions.length };
    }),

  getAttempts: protectedProcedure
    .input(z.object({ quizId: z.number() }))
    .query(async ({ ctx, input }) => {
      return db.getUserQuizAttempts(ctx.user.id, input.quizId);
    }),
});

// Socratic Tips router
export const socraticTipsRouter = router({
  generate: protectedProcedure
    .input(
      z.object({
        question: z.string(),
        options: z.array(z.string()),
        language: z.enum(["en", "pt", "es", "fr"]),
      })
    )
    .mutation(async ({ input }) => {
      const languageMap = {
        en: "English",
        pt: "Portuguese",
        es: "Spanish",
        fr: "French",
      };

      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: `You are a Socratic tutor. Generate a thought-provoking hint that guides the student to think critically WITHOUT revealing the answer. Use open-ended questions that encourage deeper thinking. The hint should be concise (1-2 sentences) and make the student reflect on the concepts involved.`,
          },
          {
            role: "user",
            content: `Question: ${input.question}\n\nOptions: ${input.options.join(", ")}\n\nProvide a Socratic hint that guides thinking without revealing the answer.`,
          },
        ],
      });

      const hint = response.choices[0]?.message?.content || "Think about the key concepts in this question.";
      return { hint: typeof hint === 'string' ? hint : JSON.stringify(hint) };
    }),
});

// Notes router
export const noteRouter = router({
  listByDocument: protectedProcedure
    .input(z.object({ documentId: z.number() }))
    .query(async ({ ctx, input }) => {
      return db.getDocumentNotes(input.documentId, ctx.user.id);
    }),

  create: protectedProcedure
    .input(
      z.object({
        documentId: z.number(),
        content: z.string(),
        highlightedText: z.string().optional(),
        position: z.number().optional(),
        color: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await db.createNote({
        userId: ctx.user.id,
        documentId: input.documentId,
        content: input.content,
        highlightedText: input.highlightedText,
        position: input.position,
        color: input.color || "yellow",
      });
      return { success: true };
    }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        content: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      await db.updateNote(input.id, input.content);
      return { success: true };
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      await db.deleteNote(input.id);
      return { success: true };
    }),
});

// Progress router
export const progressRouter = router({
  getSessions: protectedProcedure.query(async ({ ctx }) => {
    return db.getUserStudySessions(ctx.user.id);
  }),

  createSession: protectedProcedure
    .input(
      z.object({
        documentId: z.number().optional(),
        activityType: z.enum(["reading", "flashcards", "quiz", "notes"]),
        durationMinutes: z.number(),
        itemsCompleted: z.number().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await db.createStudySession({
        userId: ctx.user.id,
        documentId: input.documentId,
        activityType: input.activityType,
        durationMinutes: input.durationMinutes,
        itemsCompleted: input.itemsCompleted || 0,
      });
      return { success: true };
    }),

  getStats: protectedProcedure.query(async ({ ctx }) => {
    const sessions = await db.getUserStudySessions(ctx.user.id);
    const documents = await db.getUserDocuments(ctx.user.id);
    const flashcards = await db.getUserFlashcards(ctx.user.id);
    const quizzes = await db.getUserQuizzes(ctx.user.id);

    const totalStudyTime = sessions.reduce((sum, s) => sum + s.durationMinutes, 0);
    const flashcardsReviewed = sessions
      .filter((s) => s.activityType === "flashcards")
      .reduce((sum, s) => sum + (s.itemsCompleted || 0), 0);
    const quizzesCompleted = sessions.filter((s) => s.activityType === "quiz").length;

    return {
      totalStudyTime,
      documentsCount: documents.length,
      flashcardsCount: flashcards.length,
      flashcardsReviewed,
      quizzesCount: quizzes.length,
      quizzesCompleted,
    };
  }),
});
