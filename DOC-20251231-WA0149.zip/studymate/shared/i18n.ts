export type Language = 'en' | 'pt' | 'es' | 'fr';

export interface Translations {
  // Navigation
  nav: {
    home: string;
    documents: string;
    flashcards: string;
    quizzes: string;
    progress: string;
    settings: string;
  };
  
  // Auth
  auth: {
    login: string;
    logout: string;
    welcome: string;
    loginWith: string;
  };
  
  // Home
  home: {
    title: string;
    subtitle: string;
    getStarted: string;
    features: {
      summarize: {
        title: string;
        description: string;
      };
      flashcards: {
        title: string;
        description: string;
      };
      quizzes: {
        title: string;
        description: string;
      };
      progress: {
        title: string;
        description: string;
      };
    };
  };
  
  // Documents
  documents: {
    title: string;
    uploadNew: string;
    noDocuments: string;
    uploadPrompt: string;
    viewSummary: string;
    createFlashcards: string;
    createQuiz: string;
    delete: string;
    confirmDelete: string;
  };
  
  // Flashcards
  flashcards: {
    title: string;
    createNew: string;
    noFlashcards: string;
    front: string;
    back: string;
    difficulty: string;
    easy: string;
    medium: string;
    hard: string;
    review: string;
    dueForReview: string;
    nextReview: string;
  };
  
  // Quizzes
  quizzes: {
    title: string;
    createNew: string;
    noQuizzes: string;
    start: string;
    submit: string;
    score: string;
    correct: string;
    incorrect: string;
    viewResults: string;
  };
  
  // Progress
  progress: {
    title: string;
    studyTime: string;
    documentsRead: string;
    flashcardsReviewed: string;
    quizzesCompleted: string;
    recentActivity: string;
  };
  
  // Common
  common: {
    save: string;
    cancel: string;
    delete: string;
    edit: string;
    loading: string;
    error: string;
    success: string;
    confirm: string;
    back: string;
    next: string;
    previous: string;
  };
}

export const translations: Record<Language, Translations> = {
  en: {
    nav: {
      home: 'Home',
      documents: 'Documents',
      flashcards: 'Flashcards',
      quizzes: 'Quizzes',
      progress: 'Progress',
      settings: 'Settings',
    },
    auth: {
      login: 'Login',
      logout: 'Logout',
      welcome: 'Welcome',
      loginWith: 'Login with',
    },
    home: {
      title: 'StudyMate - Your Smart Learning Assistant',
      subtitle: 'Learn better, memorize more, and ace your exams with AI-powered study tools',
      getStarted: 'Get Started',
      features: {
        summarize: {
          title: 'Smart Summaries',
          description: 'Upload any text or document and get AI-generated summaries instantly',
        },
        flashcards: {
          title: 'Intelligent Flashcards',
          description: 'Automatically generate flashcards with spaced repetition for better memorization',
        },
        quizzes: {
          title: 'Custom Quizzes',
          description: 'Create personalized quizzes from your study materials to test your knowledge',
        },
        progress: {
          title: 'Track Progress',
          description: 'Monitor your learning journey with detailed analytics and insights',
        },
      },
    },
    documents: {
      title: 'My Documents',
      uploadNew: 'Upload New Document',
      noDocuments: 'No documents yet',
      uploadPrompt: 'Upload your first document to get started',
      viewSummary: 'View Summary',
      createFlashcards: 'Create Flashcards',
      createQuiz: 'Create Quiz',
      delete: 'Delete',
      confirmDelete: 'Are you sure you want to delete this document?',
    },
    flashcards: {
      title: 'My Flashcards',
      createNew: 'Create New Flashcard',
      noFlashcards: 'No flashcards yet',
      front: 'Front',
      back: 'Back',
      difficulty: 'Difficulty',
      easy: 'Easy',
      medium: 'Medium',
      hard: 'Hard',
      review: 'Review',
      dueForReview: 'Due for Review',
      nextReview: 'Next Review',
    },
    quizzes: {
      title: 'My Quizzes',
      createNew: 'Create New Quiz',
      noQuizzes: 'No quizzes yet',
      start: 'Start Quiz',
      submit: 'Submit',
      score: 'Score',
      correct: 'Correct',
      incorrect: 'Incorrect',
      viewResults: 'View Results',
    },
    progress: {
      title: 'My Progress',
      studyTime: 'Study Time',
      documentsRead: 'Documents Read',
      flashcardsReviewed: 'Flashcards Reviewed',
      quizzesCompleted: 'Quizzes Completed',
      recentActivity: 'Recent Activity',
    },
    common: {
      save: 'Save',
      cancel: 'Cancel',
      delete: 'Delete',
      edit: 'Edit',
      loading: 'Loading...',
      error: 'Error',
      success: 'Success',
      confirm: 'Confirm',
      back: 'Back',
      next: 'Next',
      previous: 'Previous',
    },
  },
  pt: {
    nav: {
      home: 'Início',
      documents: 'Documentos',
      flashcards: 'Flashcards',
      quizzes: 'Questionários',
      progress: 'Progresso',
      settings: 'Configurações',
    },
    auth: {
      login: 'Entrar',
      logout: 'Sair',
      welcome: 'Bem-vindo',
      loginWith: 'Entrar com',
    },
    home: {
      title: 'StudyMate - Seu Assistente Inteligente de Estudos',
      subtitle: 'Aprenda melhor, memorize mais e mande bem nas provas com ferramentas de estudo com IA',
      getStarted: 'Começar',
      features: {
        summarize: {
          title: 'Resumos Inteligentes',
          description: 'Envie qualquer texto ou documento e receba resumos gerados por IA instantaneamente',
        },
        flashcards: {
          title: 'Flashcards Inteligentes',
          description: 'Gere flashcards automaticamente com repetição espaçada para melhor memorização',
        },
        quizzes: {
          title: 'Questionários Personalizados',
          description: 'Crie questionários personalizados a partir dos seus materiais de estudo para testar seu conhecimento',
        },
        progress: {
          title: 'Acompanhe o Progresso',
          description: 'Monitore sua jornada de aprendizado com análises e insights detalhados',
        },
      },
    },
    documents: {
      title: 'Meus Documentos',
      uploadNew: 'Enviar Novo Documento',
      noDocuments: 'Nenhum documento ainda',
      uploadPrompt: 'Envie seu primeiro documento para começar',
      viewSummary: 'Ver Resumo',
      createFlashcards: 'Criar Flashcards',
      createQuiz: 'Criar Questionário',
      delete: 'Excluir',
      confirmDelete: 'Tem certeza que deseja excluir este documento?',
    },
    flashcards: {
      title: 'Meus Flashcards',
      createNew: 'Criar Novo Flashcard',
      noFlashcards: 'Nenhum flashcard ainda',
      front: 'Frente',
      back: 'Verso',
      difficulty: 'Dificuldade',
      easy: 'Fácil',
      medium: 'Médio',
      hard: 'Difícil',
      review: 'Revisar',
      dueForReview: 'Para Revisar',
      nextReview: 'Próxima Revisão',
    },
    quizzes: {
      title: 'Meus Questionários',
      createNew: 'Criar Novo Questionário',
      noQuizzes: 'Nenhum questionário ainda',
      start: 'Iniciar Questionário',
      submit: 'Enviar',
      score: 'Pontuação',
      correct: 'Correto',
      incorrect: 'Incorreto',
      viewResults: 'Ver Resultados',
    },
    progress: {
      title: 'Meu Progresso',
      studyTime: 'Tempo de Estudo',
      documentsRead: 'Documentos Lidos',
      flashcardsReviewed: 'Flashcards Revisados',
      quizzesCompleted: 'Questionários Concluídos',
      recentActivity: 'Atividade Recente',
    },
    common: {
      save: 'Salvar',
      cancel: 'Cancelar',
      delete: 'Excluir',
      edit: 'Editar',
      loading: 'Carregando...',
      error: 'Erro',
      success: 'Sucesso',
      confirm: 'Confirmar',
      back: 'Voltar',
      next: 'Próximo',
      previous: 'Anterior',
    },
  },
  es: {
    nav: {
      home: 'Inicio',
      documents: 'Documentos',
      flashcards: 'Tarjetas',
      quizzes: 'Cuestionarios',
      progress: 'Progreso',
      settings: 'Configuración',
    },
    auth: {
      login: 'Iniciar sesión',
      logout: 'Cerrar sesión',
      welcome: 'Bienvenido',
      loginWith: 'Iniciar sesión con',
    },
    home: {
      title: 'StudyMate - Tu Asistente Inteligente de Estudio',
      subtitle: 'Aprende mejor, memoriza más y destaca en tus exámenes con herramientas de estudio con IA',
      getStarted: 'Comenzar',
      features: {
        summarize: {
          title: 'Resúmenes Inteligentes',
          description: 'Sube cualquier texto o documento y obtén resúmenes generados por IA al instante',
        },
        flashcards: {
          title: 'Tarjetas Inteligentes',
          description: 'Genera tarjetas automáticamente con repetición espaciada para mejor memorización',
        },
        quizzes: {
          title: 'Cuestionarios Personalizados',
          description: 'Crea cuestionarios personalizados de tus materiales de estudio para probar tu conocimiento',
        },
        progress: {
          title: 'Seguimiento del Progreso',
          description: 'Monitorea tu viaje de aprendizaje con análisis e información detallada',
        },
      },
    },
    documents: {
      title: 'Mis Documentos',
      uploadNew: 'Subir Nuevo Documento',
      noDocuments: 'No hay documentos aún',
      uploadPrompt: 'Sube tu primer documento para comenzar',
      viewSummary: 'Ver Resumen',
      createFlashcards: 'Crear Tarjetas',
      createQuiz: 'Crear Cuestionario',
      delete: 'Eliminar',
      confirmDelete: '¿Estás seguro de que quieres eliminar este documento?',
    },
    flashcards: {
      title: 'Mis Tarjetas',
      createNew: 'Crear Nueva Tarjeta',
      noFlashcards: 'No hay tarjetas aún',
      front: 'Frente',
      back: 'Reverso',
      difficulty: 'Dificultad',
      easy: 'Fácil',
      medium: 'Medio',
      hard: 'Difícil',
      review: 'Revisar',
      dueForReview: 'Para Revisar',
      nextReview: 'Próxima Revisión',
    },
    quizzes: {
      title: 'Mis Cuestionarios',
      createNew: 'Crear Nuevo Cuestionario',
      noQuizzes: 'No hay cuestionarios aún',
      start: 'Iniciar Cuestionario',
      submit: 'Enviar',
      score: 'Puntuación',
      correct: 'Correcto',
      incorrect: 'Incorrecto',
      viewResults: 'Ver Resultados',
    },
    progress: {
      title: 'Mi Progreso',
      studyTime: 'Tiempo de Estudio',
      documentsRead: 'Documentos Leídos',
      flashcardsReviewed: 'Tarjetas Revisadas',
      quizzesCompleted: 'Cuestionarios Completados',
      recentActivity: 'Actividad Reciente',
    },
    common: {
      save: 'Guardar',
      cancel: 'Cancelar',
      delete: 'Eliminar',
      edit: 'Editar',
      loading: 'Cargando...',
      error: 'Error',
      success: 'Éxito',
      confirm: 'Confirmar',
      back: 'Atrás',
      next: 'Siguiente',
      previous: 'Anterior',
    },
  },
  fr: {
    nav: {
      home: 'Accueil',
      documents: 'Documents',
      flashcards: 'Cartes mémoire',
      quizzes: 'Quiz',
      progress: 'Progrès',
      settings: 'Paramètres',
    },
    auth: {
      login: 'Connexion',
      logout: 'Déconnexion',
      welcome: 'Bienvenue',
      loginWith: 'Se connecter avec',
    },
    home: {
      title: 'StudyMate - Votre Assistant d\'Apprentissage Intelligent',
      subtitle: 'Apprenez mieux, mémorisez plus et réussissez vos examens avec des outils d\'étude alimentés par l\'IA',
      getStarted: 'Commencer',
      features: {
        summarize: {
          title: 'Résumés Intelligents',
          description: 'Téléchargez n\'importe quel texte ou document et obtenez des résumés générés par IA instantanément',
        },
        flashcards: {
          title: 'Cartes Mémoire Intelligentes',
          description: 'Générez automatiquement des cartes mémoire avec répétition espacée pour une meilleure mémorisation',
        },
        quizzes: {
          title: 'Quiz Personnalisés',
          description: 'Créez des quiz personnalisés à partir de vos supports d\'étude pour tester vos connaissances',
        },
        progress: {
          title: 'Suivre les Progrès',
          description: 'Surveillez votre parcours d\'apprentissage avec des analyses et des informations détaillées',
        },
      },
    },
    documents: {
      title: 'Mes Documents',
      uploadNew: 'Télécharger un Nouveau Document',
      noDocuments: 'Aucun document pour le moment',
      uploadPrompt: 'Téléchargez votre premier document pour commencer',
      viewSummary: 'Voir le Résumé',
      createFlashcards: 'Créer des Cartes Mémoire',
      createQuiz: 'Créer un Quiz',
      delete: 'Supprimer',
      confirmDelete: 'Êtes-vous sûr de vouloir supprimer ce document?',
    },
    flashcards: {
      title: 'Mes Cartes Mémoire',
      createNew: 'Créer une Nouvelle Carte',
      noFlashcards: 'Aucune carte mémoire pour le moment',
      front: 'Recto',
      back: 'Verso',
      difficulty: 'Difficulté',
      easy: 'Facile',
      medium: 'Moyen',
      hard: 'Difficile',
      review: 'Réviser',
      dueForReview: 'À Réviser',
      nextReview: 'Prochaine Révision',
    },
    quizzes: {
      title: 'Mes Quiz',
      createNew: 'Créer un Nouveau Quiz',
      noQuizzes: 'Aucun quiz pour le moment',
      start: 'Commencer le Quiz',
      submit: 'Soumettre',
      score: 'Score',
      correct: 'Correct',
      incorrect: 'Incorrect',
      viewResults: 'Voir les Résultats',
    },
    progress: {
      title: 'Mes Progrès',
      studyTime: 'Temps d\'Étude',
      documentsRead: 'Documents Lus',
      flashcardsReviewed: 'Cartes Révisées',
      quizzesCompleted: 'Quiz Complétés',
      recentActivity: 'Activité Récente',
    },
    common: {
      save: 'Enregistrer',
      cancel: 'Annuler',
      delete: 'Supprimer',
      edit: 'Modifier',
      loading: 'Chargement...',
      error: 'Erreur',
      success: 'Succès',
      confirm: 'Confirmer',
      back: 'Retour',
      next: 'Suivant',
      previous: 'Précédent',
    },
  },
};

export function getTranslation(lang: Language): Translations {
  return translations[lang] || translations.en;
}
